package com.enviro.assessment.grad001.bonolo.investors.Services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import com.enviro.assessment.grad001.bonolo.investors.Entities.Investor;
import com.enviro.assessment.grad001.bonolo.investors.Repositories.InvestorRepository;

@Service
public class InvestorService {
    // @Autowired 
    private InvestorRepository investorRepo;
    
    @Autowired
    public InvestorService(InvestorRepository _investorRepository){
        this.investorRepo = _investorRepository;

        Investor investor1 = new Investor();
            investor1.setInvestorName("John");
            investor1.setInvestorSurname("Doe");
            investor1.setInvestorEmail("john.doe@example.com");
            investor1.setDateOfBirth(LocalDate.of(1990, 5, 15));
            investor1.setAddress("123 Main Street");
            investor1.setAge(31);

			investorRepo.save(investor1);

            Investor investor2 = new Investor();
            investor2.setInvestorName("Jane");
		    investor2.setInvestorSurname("Smith");
            investor2.setInvestorEmail("jane.smith@example.com");
            investor2.setDateOfBirth(LocalDate.of(1985, 8, 20));
            investor2.setAddress("456 Elm Street");
            investor2.setAge(36);
            investorRepo.save(investor2);
    }
    public List<Investor> getAllInvestors() throws Exception{
        //return new ResponseEntity<>(null) investorRepo.findAll();
        try {
            Investor i = new Investor();
            i.setAddress("pops");
            i.setAge(12);

            List<Investor> list = new ArrayList<>();
            list.add(i);
            this.investorRepo.save(i);
            List<Investor> investors = new ArrayList<>();
            this.investorRepo.findAll().forEach(investors::add);
            
            return investors;
        } catch (Exception e) {
            // TODO: handle exception
            throw new Exception("Failed to get investors");
        }
    }

    // Method to retrieve an investor by id
    public Optional<Investor> getInvestorById(Long id) {
        return investorRepo.findById(id);
    }

    // Method to save an investor
    public Investor saveInvestor(Investor investor) {
        return investorRepo.save(investor);
    }

    // Method to delete an investor
    public void deleteInvestor(Long id) {
        investorRepo.deleteById(id);
    }
}
