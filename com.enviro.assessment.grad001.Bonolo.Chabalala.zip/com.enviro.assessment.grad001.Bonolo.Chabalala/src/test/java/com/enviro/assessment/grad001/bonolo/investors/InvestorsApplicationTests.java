package com.enviro.assessment.grad001.bonolo.investors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvestorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
